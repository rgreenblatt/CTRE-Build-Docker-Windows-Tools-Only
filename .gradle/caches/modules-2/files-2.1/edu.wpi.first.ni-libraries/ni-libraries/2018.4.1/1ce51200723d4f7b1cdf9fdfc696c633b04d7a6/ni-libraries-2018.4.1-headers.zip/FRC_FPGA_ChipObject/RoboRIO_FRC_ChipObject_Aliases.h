// Copyright (c) National Instruments 2008.  All Rights Reserved.
// Do Not Edit... this file is generated!

#ifndef __RoboRIO_FRC_ChipObject_Aliases_h__
#define __RoboRIO_FRC_ChipObject_Aliases_h__

#define nRoboRIO_FPGANamespace nFRC_2018_18_0_8

#endif // __RoboRIO_FRC_ChipObject_Aliases_h__
